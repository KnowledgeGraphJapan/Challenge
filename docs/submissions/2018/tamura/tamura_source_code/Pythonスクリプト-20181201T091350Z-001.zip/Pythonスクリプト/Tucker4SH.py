"""
//主語（focus.datの番号）　述語（act.datの番号）　目的語（focus.datの番号）で入出力される
Created on Thu Aug 23 12:08:23 2018
@author: k4-tamura
"""
import pandas as pd
import matplotlib.pyplot as plt
from Tucker import Tucker

tens = pd.read_table('tensor_focused.dat',header=None,sep=' ')
arr = [[[0 for i in range(19)] for j in range(147)] for k in range(19)]
arr = {}

for i in range(19):
    for j in range(147):
        for k in range(19):
            arr[(i,j,k)]=0            
for i in range(len(tens)):
    arr[(tens[0][i],tens[1][i],tens[2][i])]=1
#データテンソル読
#タッカー分解
model = Tucker(R=3,S=15,T=3,max_iter=10)

model.fit(arr)
print("END")
residual=0
count=0
for i in arr:
    residual += abs(arr[i]-model.predict(i))
    count += 1
print(residual/count)

plt.plot(model._losses)
plt.ylabel('Loss')
plt.xlabel('# iters')
plt.title('Tucker')
plt.show()
for i in arr:
    a = model.predict(i)
    if arr[i] == 0 and a > 0.1 :
        print(i,a,arr[i])