# KGC2019

Knowledge Graph Completion Challenge 2019

構成

１．応募ドキュメント

　　ナレッジグラフ推論チャレンジ２０１９.pdf
 
２．学習用セリフデータ

　　犯人データ　：talk_cri.txt
  
  　非犯人データ：talk_inn.txt

３．分類器作成プログラム例

    Naive Bayes Classifier :KGC2019_NBC.jpynb

４．「まだらの紐」トリプル

　　ttl形式でダウンロードする方法が不明
    
