#BERTで類似度を求める

import numpy as np
import codecs
import unicodedata
from pyknp import Juman
import torch
from pytorch_transformers import BertTokenizer, BertModel

POOLING_LAYER = -2

def readlines(path):
    lines = []
    with codecs.open(path, encoding='utf-8') as f:
        for line in f:
            lines.append(unicodedata.normalize('NFKC', line.strip()))
    return lines

def text2embed(text, tokenizer, model):
    jm = Juman()
    words = [i.midasi for i in jm.analysis(text).mrph_list()]
    tokens = tokenizer.tokenize(' '.join(['[CLS]'] + words[:126] + ['[SEP]']))
    ids = torch.tensor(tokenizer.convert_tokens_to_ids(tokens)).unsqueeze(0)
    output = model(ids)
    embedding = np.mean(output[POOLING_LAYER].numpy()[0], axis=0)
    return embedding

def cosdistance(embedding1, embedding2):
    return np.dot(embedding1, embedding2) / (np.linalg.norm(embedding1) * np.linalg.norm(embedding2))


if __name__ == '__main__':

    #target = readlines('/home/ubuntu/BERT-pytorch/crookedman_kg.txt')
    #source = readlines('/home/ubuntu/BERT-pytorch/target-crookedman_kg.txt')

    #target = readlines('/home/ubuntu/BERT-pytorch/crookedman.txt')
    #source = readlines('/home/ubuntu/BERT-pytorch/target-crookedman.txt')

    target = readlines('/home/ubuntu/BERT-pytorch/hanamuko_kg.txt')
    source = readlines('/home/ubuntu/BERT-pytorch/target-hanamuko.txt')

    #target = readlines('/home/ubuntu/BERT-pytorch/hanamuko.txt')
    #source = readlines('/home/ubuntu/BERT-pytorch/target-hanamuko.txt')

    bert_path = '/home/ubuntu/BERT-pytorch/Japanese_L-12_H-768_A-12_E-30_BPE_transformers'
    tokenizer = BertTokenizer.from_pretrained(bert_path, do_lower_case=False, do_basic_tokenize=False)
    model = BertModel.from_pretrained(bert_path)
    model.eval()
    torch.set_grad_enabled(False)

    source_embd = []
    for text in source:
        source_embd.append(text2embed(text, tokenizer, model))
    target_embd = []
    for text in target:
        target_embd.append(text2embed(text, tokenizer, model))

    for i, embd1 in enumerate(source_embd):
        similarity = []
        for embd2 in target_embd:
            similarity.append(cosdistance(embd1, embd2))
        j = np.argmax(similarity)
        p = np.argsort(similarity)[::-1][1]
        print(i, source[i], j, target[j], similarity[j],p, target[p], similarity[p])
