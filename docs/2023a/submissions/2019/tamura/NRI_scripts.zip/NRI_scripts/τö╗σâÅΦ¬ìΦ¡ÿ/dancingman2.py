import cv2
import numpy as np
import sys

#入出力ファイル名
INPUT_IMAGE = './dancingman2.png'
OUTPUT_IMAGE = './dancingman2_classified.png'

#出力する人形の大きさ
SYMBOL_H = 180
SYMBOL_W = 140

def detect_figures(image):
    #イメージをグレースケールに変換して白黒反転
    grayscale = cv2.bitwise_not(cv2.cvtColor(image, cv2.COLOR_BGR2GRAY))
    #外側の輪郭線認識
    contours, _ = cv2.findContours(grayscale, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
    figures = []
    for cnt in contours:
        figures.append(cv2.boundingRect(cnt))
    return figures

def sort_figures(figures):
    #人形の輪郭線を左から右、上から下の順にソート
    max_x = max([fig[0] for fig in figures])
    max_y = max([fig[1] for fig in figures])
    max_w = max([fig[2] for fig in figures])
    max_h = max([fig[3] for fig in figures])
    figures = sorted(figures, key=lambda fig: int(fig[1]/max_h)*(max_x+max_w) + fig[0])
    figures = [[figure,  i] for i, figure in enumerate(figures)]
    return figures

def copy_image(image, rect, border=0):
    #特定の領域だけを切り出す
    x, y, w, h = rect
    figure_image = cv2.bitwise_not(np.zeros((h+border*2, w+border*2, 3), dtype=image.dtype))
    figure_image[border:border+h, border:border+w] = image[y:y+h, x:x+w]
    return figure_image

def compute_features(image, figures):
    kaze = cv2.KAZE_create()
    for figure in figures:
        figure_image = copy_image(image, figure[0], border=10)
        grayscale = cv2.cvtColor(figure_image, cv2.COLOR_BGR2GRAY)
        #シンボルのキーポイントと特徴量を検出
        kp, desc = kaze.detectAndCompute(grayscale, None)
        figure.append(desc)
    return figures

def compare_features(desc1, desc2):
    #二つの人形の類似度を求める
    #bfm = cv2.BFMatcher(cv2.NORM_L1, crossCheck=True)
    bfm = cv2.BFMatcher(cv2.NORM_L2)
    matches = bfm.knnMatch(desc1, desc2, k=2)
    score = 0
    ratio = 0.75
    for m, n in matches:
        if m.distance < ratio*n.distance:
            score += 1
    #score = score/len(matches)
    return score
    
def classify_figures(figures):
    #左上の人形から順に比較をして同じものをリストにする
    matched = []
    while len(figures):
        figure1 = figures.pop(0)
        matched.append([figure1])
        figures_ = []
        while len(figures):
            figure2 = figures.pop(0)
            score = compare_features(figure1[2], figure2[2])
            if score > 34:
                matched[-1].append(figure2)
            else:
                figures_.append(figure2)
        figures = figures_
    return matched

def draw_figures(image, matched):
    iy = len(matched)
    ix = max([len(x) for x in matched])
    #結果を出力する台紙を用意
    output_image = cv2.bitwise_not(np.zeros((iy*SYMBOL_H, ix*SYMBOL_W, 3), dtype=image.dtype))
    xo, yo = 0, 0
    for rois in matched:
        for rect, index, desc in rois:
            x, y, w, h = rect
            #人形を台紙にコピー
            output_image[yo:yo+h, xo:xo+w] = image[y:y+h, x:x+w]
            #人形に元の位置を表す番号を付ける
            cv2.putText(output_image, str(index), (xo+int(w/2), yo+int(h/2)), cv2.FONT_HERSHEY_SIMPLEX, 1.0, (0, 0, 255), 2)
            xo += SYMBOL_W
        xo = 0
        yo += SYMBOL_H
    return output_image

if __name__ == '__main__':
    #入力イメージを読み込む
    image = cv2.imread(INPUT_IMAGE)
    if image is None:
        sys.exit('Error: reading image file "{}"'.format(INPUT_IMAGE))

    #人形の描かれている領域を認識する
    figures = detect_figures(image)
    #認識された領域を位置でソートし直す
    figures = sort_figures(figures)
    print('{} figures detected'.format(len(figures)))

    #人形の特徴量を計算する
    figures = compute_features(image, figures)
    #人形を比較して分類する
    matched = classify_figures(figures)
    print('{} patterns classified'.format(len(matched)))

    #分類された人形のイメージを作成する   
    output_image = draw_figures(image, matched)
    cv2.imwrite(OUTPUT_IMAGE, output_image)
