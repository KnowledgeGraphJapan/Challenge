import cv2
import numpy as np
import sys

#入出力ファイル名
INPUT_IMAGE = './dancingman1.png'
OUTPUT_IMAGE = './dancingman1_classified.png'

#出力する人形の大きさ
SYMBOL_H = 180
SYMBOL_W = 140

def detect_figures(image):
    #イメージをグレースケールに変換して白黒反転
    grayscale = cv2.bitwise_not(cv2.cvtColor(image, cv2.COLOR_BGR2GRAY))
    #2階層までの輪郭線認識
    contours, hierarchy = cv2.findContours(grayscale, cv2.RETR_CCOMP, cv2.CHAIN_APPROX_NONE)
    figures = {}
    for i, cnt in enumerate(contours):
        if hierarchy[0][i][3] == -1:
            #人形の輪郭線の外接矩形をリストにする
            figures[i] = [cv2.boundingRect(cnt), None]
        else:
            #面積が小さすぎる輪郭線はノイズとして除外
            if cv2.contourArea(cnt) > 10:
                epsilon = 0.04*cv2.arcLength(cnt, True)
                #シンボル以外の輪郭線を多角形で近似
                approx = cv2.approxPolyDP(cnt, epsilon, True)
                #四角形は旗とみなす
                if len(approx) == 4:
                    #旗を持つ人形は旗の内接矩形をリストに加える
                    figures[hierarchy[0][i][3]][1] = cv2.boundingRect(approx)
    return figures.values()

def sort_figures(figures):
    #人形の輪郭線を左から右、上から下の順にソート
    max_x = max([fig[0][0] for fig in figures])
    max_y = max([fig[0][1] for fig in figures])
    max_w = max([fig[0][2] for fig in figures])
    max_h = max([fig[0][3] for fig in figures])
    figures = sorted(figures, key=lambda fig: int(fig[0][1]/max_h)*(max_x+max_w) + fig[0][0])
    figures = [figure + [i] for i, figure in enumerate(figures)]
    return figures
    
def copy_image(image, rect):
    #特定の領域だけを切り出す
    x, y, w, h = rect
    figure_image = cv2.bitwise_not(np.zeros((h, w, 3), dtype=image.dtype))
    figure_image[0:h, 0:w] = image[y:y+h, x:x+w]
    return figure_image

def erase_flag(figure_image, figure):
    #旗を消去する
    x, y = figure[1][0] - figure[0][0], figure[1][1] - figure[0][1]
    w, h = figure[1][2], figure[1][3]
    #消す範囲は旗の内接矩形の1.5倍
    dw, dh = int(w*1.5), int(h*1.5)
    cv2.rectangle(figure_image, (x-dw, y-dh), (x+w+dw, y+h+dh), (255, 255, 255), thickness=-1)
    #旗を消した人形の外接矩形を改めて求める
    grayscale = cv2.bitwise_not(cv2.cvtColor(figure_image, cv2.COLOR_BGR2GRAY))
    contours, _ = cv2.findContours(grayscale, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
    x, y, w, h = cv2.boundingRect(contours[0])
    return figure_image[y:y+h, x:x+w]

def compare_figures(image, figure1, figure2):
    #二つの人形の類似度を求める
    figure_image1 = copy_image(image, figure1[0])
    figure_image2 = copy_image(image, figure2[0])
    if figure1[1]:
        figure_image1 = erase_flag(figure_image1, figure1)
    if figure2[1]:
        figure_image2 = erase_flag(figure_image2, figure2)
    #イメージのサイズを揃える
    figure_image1 = cv2.resize(figure_image1, (SYMBOL_H, SYMBOL_W))
    figure_image2 = cv2.resize(figure_image2, (SYMBOL_H, SYMBOL_W))
    score = result = cv2.matchTemplate(figure_image1, figure_image2, cv2.TM_CCORR_NORMED)
    (_, score, _, _) = cv2.minMaxLoc(result)
    return score

def classify_figures(image, figures):
    #左上の人形から順に比較をして同じものをリストにする
    matched = []
    while len(figures):
        figure1 = figures.pop(0)
        matched.append([figure1])
        figures_ = []
        while len(figures):
            figure2 = figures.pop(0)
            score = compare_figures(image, figure1, figure2)
            if score > 0.98:
                matched[-1].append(figure2)
            else:
                figures_.append(figure2)
        figures = figures_
    return matched

def draw_figures(image, matched):
    iy = len(matched)
    ix = max([len(x) for x in matched])
    #結果を出力する台紙を用意
    output_image = cv2.bitwise_not(np.zeros((iy*SYMBOL_H, ix*SYMBOL_W, 3), dtype=image.dtype))
    xo, yo = 0, 0
    for rois in matched:
        for rect, flag, index in rois:
            x, y, w, h = rect
            #人形を台紙にコピー
            output_image[yo:yo+h, xo:xo+w] = image[y:y+h, x:x+w]
            #人形に元の位置を表す番号を付ける
            cv2.putText(output_image, str(index), (xo+int(w/2), yo+int(h/2)), cv2.FONT_HERSHEY_SIMPLEX, 1.0, (0, 0, 255), 2)
            #旗付きの人形は四角で囲む
            if flag:
                cv2.rectangle(output_image, (xo, yo), (xo+w, yo+h), (255, 255, 0), 3)
            xo += SYMBOL_W
        xo = 0
        yo += SYMBOL_H
    return output_image

if __name__ == '__main__':
    #入力イメージを読み込む
    image = cv2.imread(INPUT_IMAGE)
    if image is None:
        sys.exit('Error: reading image file "{}"'.format(INPUT_IMAGE))

    #人形の描かれている領域を認識する
    figures = detect_figures(image)
    #認識された領域を位置でソートし直す
    figures = sort_figures(figures)
    flags = [True for figure in figures if figure[1]]
    print('{}/{} flags/figures detected'.format(len(flags), len(figures)))

    #人形を比較して分類する
    matched = classify_figures(image, figures)
    print('{} patterns classified'.format(len(matched)))

    #分類された人形のイメージを作成する   
    output_image = draw_figures(image, matched)
    cv2.imwrite(OUTPUT_IMAGE, output_image)
